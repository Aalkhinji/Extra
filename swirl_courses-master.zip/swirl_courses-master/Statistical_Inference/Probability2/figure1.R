x <- c(0,2,2,0,0); y <- c( 0,0,1,1,0)
plot(x, y, lwd = 3, frame = FALSE, type = "l")
segments(0,0,2,1,lwd=3)
